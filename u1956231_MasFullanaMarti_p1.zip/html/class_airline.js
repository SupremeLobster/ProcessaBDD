var class_airline =
[
    [ "Airline", "class_airline.html#a3646b7cb1f7f1b5e5d91f9a7b91f3493", null ],
    [ "get_country", "class_airline.html#a51b883582943cffad268872498e660c3", null ],
    [ "get_IATA", "class_airline.html#af049dfdb86b4359a9e929bef396e09ec", null ],
    [ "get_ICAO", "class_airline.html#aa5313c5664a817cc865336a9ff5bad6c", null ],
    [ "get_name", "class_airline.html#ab72b26541b18e8bc3115ada079712e15", null ],
    [ "mostra", "class_airline.html#aa1899a60db1456d6780efc4fe6640440", null ],
    [ "a_active", "class_airline.html#a5ea6629fb20c5a0cf8c916ff3b100650", null ],
    [ "a_alias", "class_airline.html#aa4a6c891c3ad557f73d570e325567ce6", null ],
    [ "a_callsign", "class_airline.html#a98018d41360e5a746e493c3db4193a02", null ],
    [ "a_country", "class_airline.html#a4d465e281914486507afd9db57db0aa3", null ],
    [ "a_IATA", "class_airline.html#acfa328633af4291b668e89af096051ca", null ],
    [ "a_ICAO", "class_airline.html#a87660d821a6a8d94b7138983d0764b11", null ],
    [ "a_id", "class_airline.html#ab8c5058d9f104dfe2f89ebb076fd9e00", null ],
    [ "a_name", "class_airline.html#a25916ba0f7075fde218319286a0617b8", null ]
];