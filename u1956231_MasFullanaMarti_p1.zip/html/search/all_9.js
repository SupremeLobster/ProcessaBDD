var searchData=
[
  ['openfile_84',['openFile',['../utils_8h.html#a2d2f12bc80cefdb695b93233589d84bc',1,'openFile(ifstream &amp;f, const string &amp;filename):&#160;utils.cpp'],['../utils_8cpp.html#a2d2f12bc80cefdb695b93233589d84bc',1,'openFile(ifstream &amp;f, const string &amp;filename):&#160;utils.cpp']]]
];
