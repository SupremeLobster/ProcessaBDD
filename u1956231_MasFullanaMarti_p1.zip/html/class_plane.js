var class_plane =
[
    [ "Plane", "class_plane.html#ab69b3a9329e9ccff06e9124f6fb95fbb", null ],
    [ "get_name", "class_plane.html#a1b8c3d32842c736940779d3ed22a9906", null ],
    [ "a_IATA", "class_plane.html#a38e1dfc0a31a499310119972f229ec4b", null ],
    [ "a_ICAO", "class_plane.html#a34041e45ecdc394ca8873b0ee035e9f3", null ],
    [ "a_name", "class_plane.html#a11dc580e764280ed9a907ed20ffd0c8b", null ]
];