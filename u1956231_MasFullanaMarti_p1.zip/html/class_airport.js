var class_airport =
[
    [ "Airport", "class_airport.html#ae0d0848773e183e87b084f0bffd63461", null ],
    [ "get_country", "class_airport.html#a5828a1a9e3fb731634de4aa67aaa4142", null ],
    [ "get_IATA", "class_airport.html#ac33fe90defa1fe4a6ecbe85d1f99dcab", null ],
    [ "get_ICAO", "class_airport.html#a2fc94e41895ecbe8baadefcc8705c5cc", null ],
    [ "mostra", "class_airport.html#a4df1ac2135bab22da46693fe61f22ab8", null ],
    [ "a_alt", "class_airport.html#a1c6cb3f8a42b03960cdd12120b618280", null ],
    [ "a_city", "class_airport.html#a170f19103d2a6162798e5f1c4cc11247", null ],
    [ "a_country", "class_airport.html#aaa61ecc1bdb5c8945cde09f2a1f29908", null ],
    [ "a_DST", "class_airport.html#a561e4e8f3c920fbbe2f7527d583d53db", null ],
    [ "a_IATA", "class_airport.html#a551f5c927bb656eb4f13ce7148e52d4d", null ],
    [ "a_ICAO", "class_airport.html#a7956ee608bb273b32cd67335fe981e90", null ],
    [ "a_id", "class_airport.html#a43d0dd73def66ec665c7ae811a89aec7", null ],
    [ "a_lat", "class_airport.html#ab5ffbfafd69f52eaaa8b65275a429664", null ],
    [ "a_long", "class_airport.html#ab714d7e0de33c99103aebde9f488772c", null ],
    [ "a_name", "class_airport.html#a05e33d5ad937751c71d418825dc2f651", null ],
    [ "a_source", "class_airport.html#a8b3030e9200ec2159a7479ad7194f0e6", null ],
    [ "a_timezone", "class_airport.html#a9be535d2d101e0fedd642ca60fcd8bad", null ],
    [ "a_type", "class_airport.html#a2bf266610bbac8f673c14b0308eadac8", null ],
    [ "a_TZ", "class_airport.html#acf9f909977882ddfa46ffdf5108f9b4b", null ]
];