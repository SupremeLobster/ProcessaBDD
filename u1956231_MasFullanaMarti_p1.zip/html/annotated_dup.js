var annotated_dup =
[
    [ "Airline", "class_airline.html", "class_airline" ],
    [ "Airport", "class_airport.html", "class_airport" ],
    [ "Flight", "class_flight.html", "class_flight" ],
    [ "Plane", "class_plane.html", "class_plane" ],
    [ "Route", "class_route.html", "class_route" ]
];