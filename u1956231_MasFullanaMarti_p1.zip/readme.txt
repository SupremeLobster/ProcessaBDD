El programa funciona correctament.

Executar el make per compilar i el script.sh per tirar el joc de proves.