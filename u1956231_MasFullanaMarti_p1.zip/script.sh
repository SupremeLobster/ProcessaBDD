#!/bin/bash
	for i in $(ls /u/alum/u1956231/eda/p1/JocDeProves/*.txt); do
		/u/alum/u1956231/eda/p1/./main <$i
	done



